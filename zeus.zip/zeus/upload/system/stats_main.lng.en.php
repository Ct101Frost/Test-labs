<?php if(!defined('__CP__'))die();
define('LNG_STATS',                   'Summary statistics');
define('LNG_STATS_TOTAL_INFO',        'Information');
define('LNG_STATS_TOTAL_REPORTS',     'Total reports in database:');
define('LNG_STATS_TOTAL_BOTS24',      'Total active bots in 24 hours:');
define('LNG_STATS_TOTAL_BOTS',        'Total bots:');
define('LNG_STATS_TOTAL_MIN_VERSION', 'Minimal version of bot:');
define('LNG_STATS_TOTAL_MAX_VERSION', 'Maximal version of bot:');
define('LNG_STATS_FIRST_BOT',         'Time of first activity:');
define('LNG_STATS_RESET_INSTALLS',    'Reset Installs');
define('LNG_STATS_RESET_INSTALLS_Q',  'You really want to reset Installs?');
define('LNG_STATS_COUNTRYLIST_EMPTY', '-- Empty --');
define('LNG_STATS_COLUMN_INSTALLS',   'Installs (%s)');
define('LNG_STATS_COLUMN_ONLINE',     'Online (%s)');
define('LNG_STATS_BOTNET',            'Botnet:');
define('LNG_STATS_BOTNET_ACTIONS',    'Actions:');
?>