<?php
echo $_SERVER['REMOTE_ADDR'];
?>