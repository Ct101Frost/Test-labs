This software was download from darkcomet-rat.com.
be sure to have download this file from the official website.
if you buy this software you been scammed because it is free.

----
Contents
----

	- Client.exe (Main control program)
	- Edit Server Plugin Example (Demonstrate how to code your own edit server plugins)
	- Low graphic mode client\Client.exe (For older windows OS or Wine etc.. , it will run the client in a very low graphic mode recomanded if you encountred some weird graphic problem)
	- Docs (Some documentation about some functions of darkcomet)
	- Icons (A icon pack you can add any kind of icons you want)